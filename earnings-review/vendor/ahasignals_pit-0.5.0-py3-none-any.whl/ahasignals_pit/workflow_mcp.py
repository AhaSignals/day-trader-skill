"""Read-only local stdio MCP for the shared workflow engine. No collector or keys."""
import json
import sys
from . import __version__
from .audit_cli import _load
from .workflow import packet, replay

TOOLS = [
    {'name': 'review_earnings_export', 'description': 'Review native day-trader-skill facts.py JSON per metric against selected immutable filing annotations. Optional original HTML is re-extracted. Unsupported issuers, periods and metrics stay UNKNOWN; prose is retained, not semantically verified.', 'inputSchema': {'type': 'object', 'properties': {'payload': {'type': 'array', 'minItems': 1, 'maxItems': 50, 'items': {'type': 'object'}}, 'cutoff': {'type': 'string'}, 'analysis': {'type': 'string', 'maxLength': 12000}, 'sourceText': {'type': 'string', 'maxLength': 4000000}, 'mode': {'type': 'string', 'enum': ['disclosure-reconstruction', 'observed-pipeline']}}, 'required': ['payload', 'cutoff'], 'additionalProperties': False}},
    {'name': 'review_earnings_claim', 'description': 'Check an explicit CoreWeave 2025 Q2 operating-income statement against supplied original SEC HTML. Bounded English/Chinese grammar; missing source or unsupported prose stays UNKNOWN. No URL fetching.', 'inputSchema': {'type': 'object', 'properties': {'analysis': {'type': 'string', 'maxLength': 12000}, 'sourceText': {'type': 'string', 'maxLength': 4000000}, 'cutoff': {'type': 'string'}, 'mode': {'type': 'string', 'enum': ['disclosure-reconstruction', 'observed-pipeline']}}, 'required': ['analysis'], 'additionalProperties': False}},
    {'name': 'run_financial_demo', 'description': 'Run the fixed, no-key quarter-versus-YTD filing case. Not live vendor data.', 'inputSchema': {'type': 'object', 'properties': {}, 'additionalProperties': False}},
    {'name': 'inspect_financial_export', 'description': 'Inventory supplied Tushare-compatible financial rows. Missing source context remains unknown; does not authenticate values.', 'inputSchema': {'type': 'object', 'properties': {'payload': {'type': 'object'}}, 'required': ['payload'], 'additionalProperties': False}},
    {'name': 'check_financial_facts', 'description': 'Check a supplied ahasignals-pit batch: exact periods, scopes and cutoff. A pass is limited to supplied fields and checked rules.', 'inputSchema': {'type': 'object', 'properties': {'payload': {'type': 'object'}}, 'required': ['payload'], 'additionalProperties': False}},
    {'name': 'replay_financial_packet', 'description': 'Recompute an entire saved packet using this exact package version. Hashes are not signatures.', 'inputSchema': {'type': 'object', 'properties': {'packet': {'type': 'object'}}, 'required': ['packet'], 'additionalProperties': False}},
]
for tool in TOOLS:
    tool['annotations'] = {'readOnlyHint': True, 'destructiveHint': False, 'idempotentHint': True, 'openWorldHint': False}


def handle(request):
    if not isinstance(request, dict) or request.get('jsonrpc') != '2.0':
        return {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}
    if 'id' not in request:
        return None
    result = {'jsonrpc': '2.0', 'id': request['id']}
    method, params = request.get('method'), request.get('params', {})
    if method == 'initialize':
        requested = params.get('protocolVersion')
        version = requested if requested in ('2024-11-05', '2025-03-26', '2025-06-18', '2025-11-25') else '2025-11-25'
        result['result'] = {'protocolVersion': version, 'capabilities': {'tools': {}},
                            'serverInfo': {'name': 'ahasignals-financial-workflow', 'version': __version__}}
    elif method == 'ping':
        result['result'] = {}
    elif method == 'tools/list':
        result['result'] = {'tools': TOOLS}
    elif method == 'tools/call':
        try:
            name, args = params['name'], params.get('arguments', {})
            if not isinstance(args, dict):
                raise ValueError('Arguments')
            if name == 'review_earnings_export' and set(args) <= {'payload', 'cutoff', 'analysis', 'sourceText', 'mode'}:
                from .earnings_review import review_earnings_export
                value = review_earnings_export(args['payload'], args['cutoff'], args['sourceText'].encode('utf-8') if 'sourceText' in args else None, args.get('mode', 'disclosure-reconstruction'), args.get('analysis', ''))
            elif name == 'review_earnings_claim' and set(args) <= {'analysis', 'sourceText', 'cutoff', 'mode'}:
                from .claim_review import review_claim
                value = review_claim(args['analysis'], args['sourceText'].encode('utf-8') if 'sourceText' in args else None,
                                     args.get('cutoff', '2026-11-01T00:00:00Z'), args.get('mode', 'disclosure-reconstruction'))
            elif name == 'run_financial_demo' and not args:
                value = packet('demo')
            elif name in ('inspect_financial_export', 'check_financial_facts') and set(args) == {'payload'}:
                value = packet('inspect_vendor' if name == 'inspect_financial_export' else name, args['payload'])
            elif name == 'replay_financial_packet' and set(args) == {'packet'}:
                value = replay(args['packet'])
            else:
                raise ValueError('Unknown tool or extra arguments')
            result['result'] = {'content': [{'type': 'text', 'text': json.dumps(value, ensure_ascii=False, allow_nan=False)}], 'isError': False}
        except Exception:
            result['result'] = {'content': [{'type': 'text', 'text': 'Invalid input or failed replay. Do not send credentials. No network or file operation was performed.'}], 'isError': True}
    else:
        result['error'] = {'code': -32601, 'message': 'Method not found'}
    return result


def main():
    while True:
        line = sys.stdin.buffer.readline(8_000_002)
        if not line:
            return 0
        try:
            if len(line) > 8_000_000:
                return 2
            response = handle(_load(line))
        except Exception:
            response = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Invalid JSON'}}
        if response is not None:
            print(json.dumps(response, ensure_ascii=False, allow_nan=False), flush=True)


if __name__ == '__main__':
    sys.exit(main())
