"""Explicit one-document SEC capture; separate from the offline MCP query process."""
from datetime import datetime, timezone
from hashlib import sha256
import os
from pathlib import Path
import urllib.request
from .claim_review import source_manifest, bind_source
from .vendor_capture import NoRedirect, write_private


def capture(destination):
    out = Path(destination)
    if out.exists() or out.is_symlink(): raise ValueError('Output exists')
    m = source_manifest()
    request = urllib.request.Request(m['sourceUrl'], headers={'User-Agent': 'AhaSignals research research@ahasignals.com'})
    opener = urllib.request.build_opener(NoRedirect())
    with opener.open(request, timeout=25) as response:
        raw = response.read(4000001)
    bind_source(raw)  # Refuse changed/unreviewed bytes; no retries or access workarounds.
    out.mkdir(mode=0o700)
    fd = os.open(out / 'source.html', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream: stream.write(raw)
    write_private(out / 'receipt.json', {'sourceUrl': m['sourceUrl'], 'sha256': sha256(raw).hexdigest(),
                  'observedAt': datetime.now(timezone.utc).isoformat(), 'bytes': len(raw),
                  'boundary': 'Current retrieval, not proof of historical observation. Do not redistribute original filings.'})
