"""JSON CLI. Exit 0: answer; 1: withheld; 2: invalid input."""
import argparse
import hashlib
from importlib.resources import files
import json
from pathlib import Path
import sys
from . import __version__, run


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def _constant(value):
    raise ValueError('non-finite JSON constant')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', action='version', version=__version__)
    parser.add_argument('--example', choices=('select', 'quarterly-cash'),
                        help='Print a bundled synthetic JSON example to stdout, then exit')
    parser.add_argument('input', nargs='?', help='Your existing JSON file, or - for stdin; at most 2 MB')
    args = parser.parse_args()
    if args.example:
        if args.input is not None:
            parser.error('Choose either --example or an input file, not both.')
        sample = files('ahasignals_pit').joinpath('examples').joinpath(args.example + '.json')
        print(sample.read_text(encoding='utf-8'), end='')
        return 0
    if args.input is None:
        parser.error('Supply a JSON file or -. To create a sample, run: python -m ahasignals_pit --example select > input.json')
    try:
        if args.input == '-':
            raw = sys.stdin.buffer.read(2_000_001)
        else:
            with Path(args.input).open('rb') as stream:
                raw = stream.read(2_000_001)
        if len(raw) > 2_000_000:
            raise ValueError('input size')
        payload = json.loads(raw.decode('utf-8'), object_pairs_hook=_object, parse_constant=_constant)
        result = run(payload)
        print(json.dumps(dict(version=__version__, inputSha256=hashlib.sha256(raw).hexdigest(), **result), allow_nan=False, indent=2))
        return {'answer': 0, 'withheld': 1, 'invalid': 2}[result['status']]
    except FileNotFoundError:
        print('Input file not found. Relative paths are resolved from your current working directory. '
              'Create a valid sample with: python -m ahasignals_pit --example select > input.json', file=sys.stderr)
        return 2
    except OSError:
        print('Cannot read input file. Supply a readable file, not a directory, or use - for stdin.', file=sys.stderr)
        return 2
    except json.JSONDecodeError:
        print('Invalid JSON syntax. Supply a complete JSON object with double-quoted keys.', file=sys.stderr)
        return 2
    except (ValueError, TypeError, RecursionError, OverflowError):
        print('Invalid input. Supply a UTF-8 JSON file no larger than 2 MB with unique keys and finite numbers.', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
