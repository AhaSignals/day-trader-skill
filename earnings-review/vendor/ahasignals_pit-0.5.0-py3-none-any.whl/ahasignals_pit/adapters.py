"""Explicit mappings for annual SEC records; no inferred historical clocks."""
from copy import deepcopy
from .audit import RULESET, SCHEMA_VERSION

EVIDENCE_FIELDS = {'acceptedAt', 'observedAt', 'dimensions', 'documentSha256', 'contextId', 'sourceUrl'}


def from_annual_sec_records(records, requests, *, dataset, mode='observed-pipeline', evidence=None):
    """Map cash-flow-quality-momentum's extract_annual_facts output records.

    Dates must already be ISO dates (or null), e.g. explicitly formatted by the
    caller from pandas timestamps. requests supplies intended contexts/cutoffs;
    this function never infers the research question from the selected answer.
    Evidence is keyed by generated sec-000000 row IDs, not by accession alone:
    context and dimension evidence can differ within the same filing.
    """
    if not isinstance(records, list) or not 1 <= len(records) <= 2000:
        raise ValueError('Provide one to 2000 annual SEC records.')
    evidence = {} if evidence is None else evidence
    if not isinstance(evidence, dict):
        raise ValueError('Evidence must map generated fact IDs to declared fields.')
    facts = []
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ValueError('Each record must be an object.')
        fact_id = 'sec-' + str(index).zfill(6)
        extra = evidence.get(fact_id, {})
        if not isinstance(extra, dict) or set(extra) - EVIDENCE_FIELDS:
            raise ValueError('Unsupported evidence field.')
        fact = dict(factId=fact_id, cik=record.get('cik'), taxonomy='us-gaap',
                    concept=record.get('xbrl_concept'), unit=record.get('unit'),
                    start=record.get('period_start'), end=record.get('period_end'),
                    value=record.get('value'), accession=record.get('accession_number'),
                    sourceUrl=record.get('source_url'))
        # A missing start is unknown, not silently reclassified as an instant.
        # filing_date and availability_date are not acceptance/observation time.
        fact.update(deepcopy(extra))
        facts.append(fact)
    if set(evidence) - {f['factId'] for f in facts}:
        raise ValueError('Evidence references an unknown fact ID.')
    return dict(schemaVersion=SCHEMA_VERSION, ruleset=RULESET, mode=mode,
                dataset=deepcopy(dataset), facts=facts, rows=deepcopy(requests))
