"""Bounded source-bound claim review; no model calls, network or provider keys.

Only the selected filing, operating-income contexts and explicit statement grammar
are supported. Free-form inference remains unreviewed. Original bytes stay local.
"""
from datetime import datetime
from decimal import Decimal, localcontext
from hashlib import sha256
from importlib.resources import files
import json
import re
import xml.etree.ElementTree as ET

NS = {'x': 'http://www.xbrl.org/2003/instance', 'ix': 'http://www.xbrl.org/2013/inlineXBRL'}


def source_manifest():
    return json.loads(files('ahasignals_pit').joinpath('workflow_data/claim-source.json').read_text())


def bind_source(document):
    """Require reviewed original bytes AND independently extract the tagged values."""
    m = source_manifest()
    if not isinstance(document, bytes) or len(document) > 4_000_000:
        raise ValueError('Expected at most 4 MB of original filing bytes.')
    if sha256(document).hexdigest() != m['documentSha256']:
        raise ValueError('SOURCE_HASH_MISMATCH: this is not the reviewed original document.')
    if re.search(br'<!\s*(DOCTYPE|ENTITY)', document, re.I):
        raise ValueError('DTD and entities are unsupported.')
    root = ET.fromstring(document)
    result = []
    for spec in m['facts']:
        contexts = [n for n in root.findall('.//x:context', NS) if n.get('id') == spec['contextId']]
        if len(contexts) != 1:
            raise ValueError('Context missing or duplicated.')
        c = contexts[0]
        ident = c.find('x:entity/x:identifier', NS)
        if (ident is None or ident.text != m['cik'] or ident.get('scheme') != 'http://www.sec.gov/CIK'
                or c.findtext('x:period/x:startDate', namespaces=NS) != spec['start']
                or c.findtext('x:period/x:endDate', namespaces=NS) != spec['end']
                or c.find('.//x:segment', NS) is not None or c.find('.//x:scenario', NS) is not None):
            raise ValueError('Issuer, period or scope mismatch.')
        nodes = [n for n in root.findall('.//ix:nonFraction', NS)
                 if n.get('name') == m['concept'] and n.get('contextRef') == spec['contextId']]
        values = []
        for n in nodes:
            units = [u for u in root.findall('.//x:unit', NS) if u.get('id') == n.get('unitRef')]
            if (len(units) != 1 or len(units[0]) != 1 or units[0].findtext('x:measure', namespaces=NS) != 'iso4217:USD'
                    or n.get('format') != 'ixt:num-dot-decimal' or n.get('scale') != '3'
                    or n.get('sign', '') not in ('', '-') or len(n)
                    or not re.fullmatch(r'\d{1,3}(?:,\d{3})*|\d+', n.text or '')):
                raise ValueError('Unsupported unit, format or number.')
            value = Decimal(n.text.replace(',', '')) * 1000
            if n.get('sign') == '-': value = -value
            values.append(str(value))
        if not values or set(values) != {spec['value']} or not any(n.get('id') == spec['factId'] for n in nodes):
            raise ValueError('Extracted value conflicts with reviewed binding.')
        result.append({**spec, 'value': values[0], 'unit': 'USD', 'dimensions': [], 'concept': m['concept']})
    return result


def parse_claim(text):
    """Conservative, disclosed grammar. Never guess negation, issuer or period."""
    if not isinstance(text, str) or not text.strip() or len(text) > 12000:
        raise ValueError('Provide 1..12000 characters of analysis.')
    # An inference following these delimiters is retained, never marked verified.
    parts = re.split(r'(?i)(?:[，,]\s*所以|[，,]\s*因此|。|\.\s+|\n)', text.strip(), maxsplit=1)
    statement = parts[0].strip().rstrip('.')
    cn = re.fullmatch(r'CoreWeave\s*2025\s*年?\s*(?:第二季度|Q2)\s*(?:单季)?\s*营业(利润|亏损)\s*(?:为|是)\s*(\d+(?:\.\d+)?)\s*(万|百万)?美元', statement, re.I)
    en = re.fullmatch(r'CoreWeave\s+(?:2025\s+Q2|Q2\s+2025)\s+operating\s+(income|profit|loss)\s+(?:was|is)\s+(?:USD\s+|\$)(\d+(?:\.\d+)?)\s*(million|thousand)?', statement, re.I)
    match = cn or en
    if not match:
        return {'status': 'UNKNOWN', 'reason': 'UNSUPPORTED_OR_AMBIGUOUS_CLAIM', 'unreviewedText': text}
    kind, number, scale = match.groups()
    with localcontext() as context:
        context.prec = len(number) + 16
        value = Decimal(number) * {'万': 10000, '百万': 1000000, 'million': 1000000, 'thousand': 1000, None: 1}[scale.lower() if scale else None]
        if kind.lower() in ('亏损', 'loss'): value = value.copy_negate()
        value_text = format(value.normalize(), 'f')
    return {'status': 'MAPPED', 'statement': statement, 'value': value_text,
            'unit': 'USD', 'start': '2025-04-01', 'end': '2025-06-30',
            'concept': 'us-gaap:OperatingIncomeLoss', 'unreviewedText': parts[1].strip() if len(parts) > 1 else '',
            'method': 'bounded-explicit-grammar-v1; no model or general prose understanding'}


def review_claim(text, document=None, cutoff='2026-11-01T00:00:00Z', mode='disclosure-reconstruction'):
    m = source_manifest()
    if not isinstance(cutoff, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})', cutoff):
        raise ValueError('Use an ISO timestamp with seconds, timezone and at most six fractional digits.')
    at = datetime.fromisoformat(cutoff.replace('Z', '+00:00'))
    if at.tzinfo is None or mode not in ('disclosure-reconstruction', 'observed-pipeline'):
        raise ValueError('An explicit timezone and supported cutoff mode are required.')
    mapped = parse_claim(text)
    result = {'schemaVersion': '1.0', 'caseId': m['caseId'], 'claim': text, 'mapping': mapped,
              'cutoff': cutoff, 'mode': mode, 'status': 'UNKNOWN', 'sourceBinding': 'NOT_RUN',
              'source': {k: m[k] for k in ('sourceUrl', 'accession', 'documentSha256', 'sourceObservedAt', 'acceptedAt', 'acceptedAtBasis', 'location')},
              'boundary': 'Only the mapped operating-income amount is checked. Further interpretation is not automated. Not investment advice or independent assurance.',
              'nextQuestion': 'Compare the prior-year quarter, costs and cash flows before judging operating improvement.'}
    if document is None:
        return dict(result, reason='SOURCE_REQUIRED', correction=None)
    try:
        facts = bind_source(document)
    except (ValueError, ET.ParseError):
        return dict(result, reason='SOURCE_BINDING_FAILED', sourceBinding='FAILED', correction=None)
    result.update(sourceBinding='VERIFIED_REVIEWED_BYTES_AND_IXBRL', extractedFacts=facts)
    if at < datetime.fromisoformat(m['acceptedAt'].replace('Z', '+00:00')):
        return dict(result, reason='FILING_AFTER_CUTOFF', correction=None)
    if mode == 'observed-pipeline' and at < datetime.fromisoformat(m['sourceObservedAt']):
        return dict(result, reason='NO_CAPTURE_BY_CUTOFF', correction=None)
    if mapped['status'] != 'MAPPED':
        return dict(result, reason=mapped['reason'], correction=None)
    correct = Decimal(mapped['value']) == Decimal(facts[0]['value'])
    reason = 'AMOUNT_MATCHES' if correct else ('YTD_USED_AS_QUARTER' if Decimal(mapped['value']) == Decimal(facts[1]['value']) else 'AMOUNT_DIFFERS')
    return dict(result, status='SUPPORTED' if correct else 'CORRECTION_REQUIRED', reason=reason,
                correction='CoreWeave 2025 Q2 operating income was USD 19.209 million. The USD 8.261 million operating loss covers January–June, not the single quarter.',
                interpretation='This amount alone does not establish net profit, cash generation, business improvement or investment value.',
                inferenceStatus='NOT_REVIEWED' if mapped['unreviewedText'] else 'NOT_REQUESTED')


def verify_declared_fact(document, declared):
    """Compare supplied fact fields to extracted source; metadata PASS is insufficient."""
    facts = bind_source(document)
    keys = ('contextId', 'start', 'end', 'unit', 'concept', 'dimensions')
    matches = [f for f in facts if all(declared.get(k) == f[k] for k in keys)]
    if len(matches) != 1: return {'status': 'UNKNOWN', 'reason': 'CONTEXT_NOT_BOUND'}
    try: same = Decimal(str(declared['value'])) == Decimal(matches[0]['value'])
    except Exception: return {'status': 'UNKNOWN', 'reason': 'INVALID_VALUE'}
    return {'status': 'SUPPORTED' if same else 'CORRECTION_REQUIRED', 'expectedValue': matches[0]['value'], 'unit': 'USD'}


def report_markdown(result):
    return ('# 财报主张原文核对\n\n' + result['status'] + ' — ' + result['reason'] + '\n\n'
            + '原分析：' + result['claim'] + '\n\n'
            + '数值绑定：' + result['sourceBinding'] + '\n\n'
            + (result.get('correction') or '尚不能给出已验证的修正。请提供原文或明确公司、期间、指标与数值。') + '\n\n'
            + result.get('interpretation', '') + '\n\n未审阅的后续文字：' + result['mapping'].get('unreviewedText', '') + '\n\n'
            + '[' + result['source']['location'] + '](' + result['source']['sourceUrl'] + ')\n\n'
            + result['boundary'] + '\n')
