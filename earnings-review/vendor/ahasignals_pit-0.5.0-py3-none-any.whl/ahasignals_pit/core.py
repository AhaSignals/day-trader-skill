"""Deterministic checks of supplied facts, provenance fields and declared clocks."""
from copy import deepcopy
from datetime import date, datetime, timedelta
import math
import re

MAX_VALUE = 2**53 - 1
MODES = ('disclosure-reconstruction', 'observed-pipeline')
CLOCK = re.compile(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})', re.ASCII)
EVIDENCE = ('cik', 'taxonomy', 'concept', 'unit', 'start', 'end', 'dimensions',
            'value', 'accession', 'acceptedAt', 'observedAt', 'sourceUrl',
            'documentSha256', 'contextId')


def _matches(pattern, value):
    return isinstance(value, str) and re.fullmatch(pattern, value, re.ASCII) is not None


def _instant(value):
    """Return integer nanoseconds, rejecting ambiguous zones and invalid dates."""
    if not isinstance(value, str):
        return None
    m = CLOCK.fullmatch(value)
    if not m:
        return None
    year, month, day, hour, minute, second = map(int, m.groups()[:6])
    fraction, zone = m.groups()[6:]
    if year < 1900 or zone == '-00:00':
        return None
    try:
        clock = datetime(year, month, day, hour, minute, second)
    except ValueError:
        return None
    offset = 0
    if zone != 'Z':
        hours, minutes = int(zone[1:3]), int(zone[4:6])
        if hours > 14 or minutes > 59 or (hours == 14 and minutes):
            return None
        offset = (hours * 60 + minutes) * 60 * (1 if zone[0] == '+' else -1)
    delta = clock - datetime(1970, 1, 1)
    return (delta.days * 86400 + delta.seconds - offset) * 10**9 + int((fraction or '').ljust(9, '0'))


def _date(value):
    return _matches(r'\d{4}-\d{2}-\d{2}', value) and _instant(value + 'T00:00:00Z') is not None


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def _dimensions(value):
    if not isinstance(value, list) or len(value) > 32:
        return None
    pairs = []
    axes = set()
    for item in value:
        if (not isinstance(item, dict) or set(item) != {'axis', 'member'}
                or not _text(item['axis']) or not _text(item['member']) or item['axis'] in axes):
            return None
        axes.add(item['axis'])
        pairs.append((item['axis'], item['member']))
    return tuple(sorted(pairs))


def _identity(value):
    return (isinstance(value, dict) and _matches(r'\d{10}', value.get('cik'))
            and all(_text(value.get(k)) for k in ('taxonomy', 'concept', 'unit'))
            and _date(value.get('end'))
            and (value.get('start') == '' or (_date(value.get('start')) and value['start'] <= value['end']))
            and _dimensions(value.get('dimensions')) is not None)


def _key(value):
    return tuple(value[k] for k in ('cik', 'taxonomy', 'concept', 'unit', 'start', 'end')) + (_dimensions(value['dimensions']),)


def _number(value):
    return type(value) in (int, float) and abs(value) <= MAX_VALUE and math.isfinite(value)


def _whole(value):
    return _number(value) and int(value) == value


def _valid_fact(fact):
    return (_identity(fact) and _number(fact.get('value'))
            and _matches(r'\d{10}-\d{2}-\d{6}', fact.get('accession'))
            and _instant(fact.get('acceptedAt')) is not None
            and _matches(r'[a-f0-9]{64}', fact.get('documentSha256'))
            and _text(fact.get('contextId')) and isinstance(fact.get('sourceUrl'), str)
            and fact['sourceUrl'].startswith('https://'))


def _stop(reason, status='withheld'):
    return dict(status=status, reason=reason, value=None, inputs=[])


def select_fact(facts, query):
    """Select the latest eligible exact context; return answer/withheld/invalid.

    Inputs use the camelCase JSON contract documented in README.md. This does
    not fetch documents or authenticate their hashes or declared timestamps.
    """
    if (not isinstance(facts, list) or len(facts) > 2000 or not _identity(query)
            or _instant(query.get('cutoff')) is None or query.get('mode') not in MODES):
        return _stop('invalid-query-or-facts', 'invalid')
    if 'accession' in query and not _matches(r'\d{10}-\d{2}-\d{6}', query['accession']):
        return _stop('invalid-accession-filter', 'invalid')
    if not all(_valid_fact(f) for f in facts):
        return _stop('invalid-fact-or-missing-provenance', 'invalid')
    matched = [f for f in facts if _key(f) == _key(query) and ('accession' not in query or f['accession'] == query['accession'])]
    if not matched:
        return _stop('no-matching-context')
    cutoff = _instant(query['cutoff'])
    accepted = [f for f in matched if _instant(f['acceptedAt']) <= cutoff]
    if not accepted:
        return _stop('source-after-cutoff')
    eligible = accepted
    if query['mode'] == 'observed-pipeline':
        if any(_instant(f.get('observedAt')) is None for f in accepted):
            return _stop('unknown-observation-time')
        if any(_instant(f['observedAt']) < _instant(f['acceptedAt']) for f in accepted):
            return _stop('observation-before-acceptance')
        eligible = [f for f in accepted if _instant(f['observedAt']) <= cutoff]
        if not eligible:
            return _stop('observation-after-cutoff')
    latest = max(_instant(f['acceptedAt']) for f in eligible)
    selected = [f for f in eligible if _instant(f['acceptedAt']) == latest]
    if len({(f['value'], f['accession'], f['documentSha256']) for f in selected}) != 1:
        return _stop('ambiguous-latest-fact')
    fact = min(selected, key=lambda f: f['contextId'])
    return dict(status='answer', reason='latest-eligible-exact-context', value=fact['value'],
                inputs=[{k: deepcopy(fact.get(k)) for k in EVIDENCE}], mode=query['mode'], cutoff=query['cutoff'])


def quarterly_cash(facts, request):
    """Reconstruct consolidated whole-USD quarterly OCF less cash PP&E.

    Exact-quarter duration wins; otherwise subtract matched fiscal YTD periods.
    This is not a universal free-cash-flow definition or a trading signal.
    """
    if not isinstance(request, dict):
        return _stop('invalid-quarter-request', 'invalid')
    fiscal, start, end = (request.get(k) for k in ('fiscalStart', 'quarterStart', 'end'))
    mode, cutoff, computed = (request.get(k) for k in ('mode', 'cutoff', 'computedAt'))
    if (not all(_date(d) for d in (fiscal, start, end)) or fiscal > start or start > end
            or mode not in MODES or _instant(cutoff) is None):
        return _stop('invalid-quarter-request', 'invalid')
    if not 60 <= (date.fromisoformat(end) - date.fromisoformat(start)).days + 1 <= 120:
        return _stop('not-a-quarter-length')
    previous = (date.fromisoformat(start) - timedelta(days=1)).isoformat()
    inputs, amounts, methods = [], {}, []
    for name, concept in (('operatingCash', 'NetCashProvidedByUsedInOperatingActivities'),
                          ('cashPpe', 'PaymentsToAcquirePropertyPlantAndEquipment')):
        query = dict(cik=request.get('cik'), taxonomy='us-gaap', concept=concept, unit='USD',
                     start=fiscal, end=end, dimensions=[], cutoff=cutoff, mode=mode)
        direct = select_fact(facts, dict(query, start=start))
        if direct['status'] == 'answer':
            if not _whole(direct['value']):
                return _stop('cash-values-must-be-exact-whole-dollars')
            amounts[name] = int(direct['value'])
            inputs.extend(direct['inputs'])
            methods.append('direct-quarter-duration')
            continue
        if direct['reason'] != 'no-matching-context':
            return dict(direct, reason=name + ':' + direct['reason'])
        current = select_fact(facts, query)
        if current['status'] != 'answer':
            return dict(current, reason=name + ':' + current['reason'])
        prior = dict(value=0, inputs=[])
        if fiscal != start:
            prior = select_fact(facts, dict(query, end=previous))
            if prior['status'] != 'answer':
                return dict(prior, reason=name + ':' + prior['reason'])
        if not all(_whole(v) for v in (current['value'], prior['value'])):
            return _stop('cash-values-must-be-exact-whole-dollars')
        amounts[name] = int(current['value']) - int(prior['value'])
        inputs.extend(current['inputs'] + prior['inputs'])
        methods.append('difference-of-matched-ytd-periods')
    if amounts['cashPpe'] < 0:
        return _stop('negative-cash-ppe-needs-source-review')
    cash = amounts['operatingCash'] - amounts['cashPpe']
    if not all(_whole(v) for v in (*amounts.values(), cash)):
        return _stop('derived-value-out-of-range')
    if mode == 'observed-pipeline':
        ct = _instant(computed)
        if ct is None:
            return _stop('unknown-computation-time')
        if ct > _instant(cutoff):
            return _stop('computation-after-cutoff')
        if any(_instant(f['observedAt']) > ct for f in inputs):
            return _stop('computation-before-input')
    return dict(status='answer', reason='+'.join(dict.fromkeys(methods)), **amounts,
                cashAfterPpe=cash, unit='USD', start=start, end=end, cutoff=cutoff,
                mode=mode, computedAt=computed, inputs=inputs,
                selectionPolicy='Latest eligible filing per exact fiscal period; cross-filing inputs are identified, not assumed to have a common presentation vintage.',
                boundary='Declared consolidated US-GAAP cash flows. Cash PP&E excludes noncash additions and other investment spending. No historical observation or computation time is inferred; no predictive claim.')


def run(payload):
    """Dispatch a JSON-compatible select or quarterly-cash request."""
    if not isinstance(payload, dict):
        return dict(status='invalid', reason='invalid-input')
    if payload.get('task') == 'select':
        return select_fact(payload.get('facts'), payload.get('query'))
    if payload.get('task') == 'quarterly-cash':
        return quarterly_cash(payload.get('facts'), payload.get('request'))
    return dict(status='invalid', reason='unknown-task')
