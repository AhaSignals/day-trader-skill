"""Offline batch audit. Exit 0 PASS, 1 FAIL, 2 ERROR, 3 UNKNOWN."""
import argparse
import hashlib
from importlib.resources import files
import json
from pathlib import Path
import sys
from . import __version__
from .__main__ import _object, _constant
from .audit import audit_batch


def _load(raw):
    return json.loads(raw.decode('utf-8'), object_pairs_hook=_object, parse_constant=_constant)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', action='version', version=__version__)
    sub = parser.add_subparsers(dest='command', required=True)
    example = sub.add_parser('example', help='Print a synthetic batch, not issuer evidence')
    example.add_argument('kind', choices=('pass', 'fail', 'unknown'))
    schema = sub.add_parser('schema', help='Print the versioned JSON schema')
    schema.add_argument('kind', choices=('input', 'report'))
    check = sub.add_parser('check', help='Read JSON batch or manifest plus JSONL facts')
    check.add_argument('--input', required=True, help='Existing JSON batch/manifest path, or - for stdin')
    check.add_argument('--facts-jsonl', help='JSONL facts path; manifest must not also contain facts')
    args = parser.parse_args()
    root = files('ahasignals_pit')
    if args.command == 'schema':
        print(root.joinpath('schemas').joinpath('audit-' + args.kind + '.schema.json').read_text(), end='')
        return 0
    if args.command == 'example':
        print(root.joinpath('examples').joinpath('audit-' + args.kind + '.json').read_text(), end='')
        return 0
    try:
        def read(path):
            if path == '-':
                raw = sys.stdin.buffer.read(8_000_001)
            else:
                with Path(path).open('rb') as stream:
                    raw = stream.read(8_000_001)
            if len(raw) > 8_000_000:
                raise ValueError('size')
            return raw
        raw = read(args.input)
        payload = _load(raw)
        hashes = {'inputBytesSha256': hashlib.sha256(raw).hexdigest()}
        if args.facts_jsonl:
            if not isinstance(payload, dict) or 'facts' in payload or args.facts_jsonl == '-':
                raise ValueError('manifest')
            fact_bytes = read(args.facts_jsonl)
            lines = fact_bytes.splitlines()
            if not 1 <= len(lines) <= 2000 or any(not line.strip() for line in lines):
                raise ValueError('jsonl')
            payload['facts'] = [_load(line) for line in lines]
            hashes['factsBytesSha256'] = hashlib.sha256(fact_bytes).hexdigest()
        report = audit_batch(payload)
        report['transportHashes'] = hashes
        print(json.dumps(report, indent=2, allow_nan=False))
        return {'PASS': 0, 'FAIL': 1, 'ERROR': 2, 'UNKNOWN': 3}[report['gate']]
    except (OSError, ValueError, TypeError, RecursionError, OverflowError):
        # Do not echo file paths, raw values or exception messages into logs.
        report = audit_batch(None)
        report['errors'] = [{'code': 'unreadable-or-invalid-input', 'message': 'Use UTF-8 JSON with unique keys and finite numbers, at most 8 MB per file; JSONL needs one fact per nonempty line.'}]
        print(json.dumps(report, indent=2))
        return 2


if __name__ == '__main__':
    sys.exit(main())
