"""Compare declared cutoffs offline. This demonstration is not a CI admission gate."""
import argparse
from copy import deepcopy
import hashlib
from importlib.resources import files
import json
from pathlib import Path
import sys

from . import __version__
from .audit import audit_batch
from .audit_cli import _load


def replay(payload, later_cutoff):
    """Keep facts and selection fixed; vary only cutoff and the stated time mode."""
    if audit_batch(payload)['gate'] == 'ERROR' or len(payload['rows']) != 1:
        raise ValueError('Replay requires one valid feature-use row.')
    cases = []
    for name, mode, cutoff in (
        ('original-cutoff', 'disclosure-reconstruction', payload['rows'][0]['cutoff']),
        ('comparison-cutoff', 'disclosure-reconstruction', later_cutoff),
        ('observation-check', 'observed-pipeline', later_cutoff),
    ):
        current = deepcopy(payload)
        current['mode'] = mode
        current['rows'][0]['cutoff'] = cutoff
        report = audit_batch(current)
        if report['gate'] == 'ERROR':
            raise ValueError('Invalid replay cutoff or input.')
        cases.append({'case': name, 'input': current, 'report': report})
    return {
        'packageVersion': __version__,
        'purpose': 'Controlled cutoff comparison; not an observed third-party pipeline error.',
        'boundary': 'Facts, selected version and provenance are unchanged. Source authenticity and actual historical access are not established. A later cutoff is a different research question, not a repair of an earlier backtest.',
        'cases': cases,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', help='Existing single-row batch JSON; omitted uses a synthetic example')
    parser.add_argument('--later-cutoff', help='Explicit comparison cutoff with timezone; required with --input')
    args = parser.parse_args()
    if bool(args.input) != bool(args.later_cutoff):
        parser.error('--input and --later-cutoff must be supplied together')
    try:
        if args.input:
            with Path(args.input).open('rb') as stream:
                raw = stream.read(8_000_001)
            if len(raw) > 8_000_000:
                raise ValueError('oversize')
            payload = _load(raw)
            cutoff = args.later_cutoff
        else:
            raw = files('ahasignals_pit').joinpath('examples').joinpath('audit-unknown.json').read_bytes()
            payload = _load(raw)
            payload['rows'][0]['cutoff'] = '2025-04-30T23:59:59Z'
            cutoff = '2025-05-01T00:00:00Z'
        result = replay(payload, cutoff)
        result['inputKind'] = 'caller-supplied' if args.input else 'fully-synthetic-not-company-data'
        result['sourceInputBytesSha256'] = hashlib.sha256(raw).hexdigest()
        print(json.dumps(result, indent=2, allow_nan=False))
        # A completed demonstration can contain FAIL/UNKNOWN. Use audit_cli check
        # (0/1/2/3) when enforcing a pipeline admission decision.
        return 0
    except (OSError, ValueError, TypeError, RecursionError, OverflowError):
        print('Replay requires valid UTF-8 batch JSON with one row, unique keys, finite numbers and an explicit zoned cutoff (maximum 8 MB).', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
