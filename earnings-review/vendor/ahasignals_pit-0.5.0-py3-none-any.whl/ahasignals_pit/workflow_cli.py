"""Run a no-key case, inspect an export, or explicitly collect a personal response."""
import argparse
import getpass
import json
import os
from pathlib import Path
import sys
import warnings
from . import __version__
from .audit_cli import _load
from .workflow import ENDPOINTS, packet, replay, markdown


def read(path):
    with Path(path).open('rb') as stream:
        data = stream.read(8_000_001)
    if len(data) > 8_000_000:
        raise ValueError('Input too large.')
    return _load(data)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--version', action='version', version=__version__)
    sub = p.add_subparsers(dest='command', required=True)
    for name in ('demo', 'inspect', 'check'):
        command = sub.add_parser(name)
        if name != 'demo':
            command.add_argument('--input', required=True)
        command.add_argument('--out', required=True, help='New output directory; existing paths refused')
    command = sub.add_parser('review-export')
    command.add_argument('--input', required=True, help='day-trader-skill facts.py --json output')
    command.add_argument('--cutoff', required=True)
    command.add_argument('--source', help='Original reviewed SEC HTML, optional; otherwise annotation-only')
    command.add_argument('--analysis', help='Original analysis text retained as unreviewed')
    command.add_argument('--mode', choices=['disclosure-reconstruction', 'observed-pipeline'], default='disclosure-reconstruction')
    command.add_argument('--out', required=True)
    command = sub.add_parser('earnings-demo')
    command.add_argument('--out', required=True)
    command.add_argument('--source', help='Optional original SEC HTML for re-extraction')
    command = sub.add_parser('review-claim')
    command.add_argument('--analysis', required=True, help='UTF-8 analysis text file')
    command.add_argument('--source', help='Original SEC HTML file; absent means UNKNOWN')
    command.add_argument('--cutoff', default='2026-11-01T00:00:00Z')
    command.add_argument('--mode', choices=['disclosure-reconstruction', 'observed-pipeline'], default='disclosure-reconstruction')
    command.add_argument('--out', required=True, help='New private output directory')
    command = sub.add_parser('fetch-claim-source')
    command.add_argument('--out', required=True, help='New private directory for one public SEC filing')
    command = sub.add_parser('replay'); command.add_argument('--input', required=True)
    command = sub.add_parser('fetch-tushare')
    command.add_argument('--endpoint', choices=ENDPOINTS, default='us_income')
    command.add_argument('--symbol', required=True)
    command.add_argument('--period', required=True)
    command.add_argument('--out', required=True, help='New private receipt filename')
    command.add_argument('--prompt-token', action='store_true', help='Human-operated hidden terminal prompt; never use in an agent transcript')
    args = p.parse_args()
    try:
        if args.command in ('review-export', 'earnings-demo'):
            from .earnings_review import review_earnings_export, markdown as earnings_markdown
            from .vendor_capture import write_private
            from importlib.resources import files
            source = None
            if args.source:
                with Path(args.source).open('rb') as stream: source = stream.read(4_000_001)
            tasks = []
            if args.command == 'earnings-demo':
                for name in ('correct', 'wrong', 'insufficient'):
                    case = json.loads(files('ahasignals_pit').joinpath('workflow_data/earnings-'+name+'.json').read_text())
                    tasks.append((name, case['export'], case['cutoff'], case['analysis'], 'disclosure-reconstruction'))
            else:
                text = ''
                if args.analysis:
                    with Path(args.analysis).open('rb') as stream: text = stream.read(48_001).decode('utf-8')
                tasks.append(('review', read(args.input), args.cutoff, text, args.mode))
            results = [(name, review_earnings_export(payload, cutoff, source, mode, analysis))
                       for name, payload, cutoff, analysis, mode in tasks]
            out = Path(args.out); out.mkdir(mode=0o700)
            for name, result in results:
                write_private(out / (name+'.json'), result)
                fd = os.open(out / (name+'.md'), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, 'w', encoding='utf-8') as stream: stream.write(earnings_markdown(result))
                print(name+': '+result['status']+' / '+result['evidenceLevel'])
            return 0  # Execution succeeded; inspect per-field statuses.
        if args.command == 'fetch-claim-source':
            from .claim_capture import capture
            capture(args.out)
            print('Original filing and current capture receipt saved privately. No historical capture was inferred.')
            return 0
        if args.command == 'review-claim':
            from .claim_review import review_claim, report_markdown
            from .vendor_capture import write_private
            with Path(args.analysis).open('rb') as stream: analysis = stream.read(48001)
            if len(analysis) > 48000: raise ValueError('Analysis too large')
            source = None
            if args.source:
                with Path(args.source).open('rb') as stream: source = stream.read(4000001)
            result = review_claim(analysis.decode('utf-8'), source, args.cutoff, args.mode)
            out = Path(args.out); out.mkdir(mode=0o700)
            write_private(out / 'review.json', result)
            fd = os.open(out / 'report.md', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as stream: stream.write(report_markdown(result))
            print(result['status'] + ' — ' + result['reason'])
            return 0  # successful execution, not a financial PASS; inspect status
        if args.command == 'replay':
            print(json.dumps(replay(read(args.input))))
            return 0
        if args.command == 'fetch-tushare':
            from .vendor_capture import fetch, write_private
            if Path(args.out).exists() or Path(args.out).is_symlink():
                raise ValueError('Output exists.')
            token = os.environ.get('TUSHARE_TOKEN')
            if args.prompt_token:
                if not sys.stdin.isatty():
                    raise ValueError('Hidden prompt requires a human terminal.')
                with warnings.catch_warnings():
                    warnings.simplefilter('error', getpass.GetPassWarning)
                    token = getpass.getpass('Personal Tushare token (hidden; never saved): ')
            if not token:
                print('No credential supplied. Use your local secret environment or a human-operated --prompt-token terminal. Never paste tokens into chat. The demo needs no key.', file=sys.stderr)
                return 2
            write_private(args.out, fetch(args.endpoint, args.symbol, args.period, token))
            print('Private response saved. Run inspect next. Provider access does not establish financial evidence.')
            return 0
        operation = {'demo': 'demo', 'inspect': 'inspect_vendor', 'check': 'check_financial_facts'}[args.command]
        saved = packet(operation, None if args.command == 'demo' else read(args.input))
        report = markdown(saved)
        out = Path(args.out)
        out.mkdir(mode=0o700)  # Refuse overwrite; do not publish private provider data.
        from .vendor_capture import write_private
        write_private(out / 'packet.json', saved)
        fd = os.open(out / 'report.md', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(report)
        print('Created packet.json and report.md. Replay the packet with the same package version.')
        if operation == 'check_financial_facts':
            return {'PASS': 0, 'FAIL': 1, 'ERROR': 2, 'UNKNOWN': 3}[saved['result']['gate']]
        return 0
    except Exception:
        # Deliberately do not echo paths, raw provider messages, tokens or stack traces.
        print('Operation stopped. Check input schema, new output path, personal endpoint permission and TLS connectivity. No automatic retry, insecure fallback or paid access was attempted.', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
