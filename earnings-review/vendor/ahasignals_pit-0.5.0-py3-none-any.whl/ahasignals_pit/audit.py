"""Offline batch checks of declared financial feature inputs, not assurance."""
from copy import deepcopy
import hashlib
import json
from .core import _date, _dimensions, _identity, _instant, _key, _matches, _number, _text

RULESET = 'sec-financial-facts-v1'
SCHEMA_VERSION = '1.0'
LIMITATIONS = [
    'Source documents and operator timestamps are not authenticated.',
    'Candidate history completeness is not established by this report.',
    'Non-reliance notices, restatement meaning and cross-filing comparability are not checked.',
    'Market data, survivorship, execution costs, model memory and profitability are not checked.',
]
IDENTITY = {'cik', 'taxonomy', 'concept', 'unit', 'start', 'end', 'dimensions'}
FACT_FIELDS = IDENTITY | {'factId', 'value', 'accession', 'acceptedAt', 'observedAt',
                          'sourceUrl', 'documentSha256', 'contextId'}
RULES = {
    'PIT-TIME-001': ('Acceptance cutoff', 'Supply the controlling filing acceptance timestamp with timezone; do not substitute period end or filing date.'),
    'PIT-TIME-002': ('Observation cutoff', 'Supply this pipeline\'s actual acquisition time; do not backdate it or use another operator\'s receipt.'),
    'PIT-CONTEXT-001': ('Exact requested context', 'Match issuer, literal concept, unit, period and dimensions to the intended feature.'),
    'PIT-VERSION-001': ('Latest eligible declared candidate', 'Inspect the supplied candidate history and resolve conflicting or later eligible versions without overwriting evidence.'),
    'PIT-EVIDENCE-001': ('Declared provenance completeness', 'Provide accession, context ID, HTTPS source URL and document SHA-256; these fields still require independent authentication.'),
}


def _id(value):
    return isinstance(value, str) and _matches(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,127}', value)


def _fact_error(fact):
    if not isinstance(fact, dict) or set(fact) - FACT_FIELDS:
        return 'invalid-fact-fields'
    if not _id(fact.get('factId')) or not _number(fact.get('value')):
        return 'invalid-fact-id-or-value'
    # Missing identity evidence is unknown. Malformed supplied evidence is invalid.
    for k in IDENTITY:
        v = fact.get(k)
        if v is None:
            continue
        valid = (_matches(r'\d{10}', v) if k == 'cik' else
                 _dimensions(v) is not None if k == 'dimensions' else
                 (v == '' or _date(v)) if k == 'start' else
                 _date(v) if k == 'end' else _text(v))
        if not valid:
            return 'invalid-context-field:' + k
    if fact.get('start') and fact.get('end') and fact['start'] > fact['end']:
        return 'invalid-period-order'
    for k in ('acceptedAt', 'observedAt'):
        if fact.get(k) is not None and _instant(fact[k]) is None:
            return 'invalid-clock:' + k
    for k, pattern in (('accession', r'\d{10}-\d{2}-\d{6}'), ('documentSha256', r'[a-f0-9]{64}')):
        if fact.get(k) is not None and not _matches(pattern, fact[k]):
            return 'invalid-provenance-field:' + k
    if fact.get('contextId') is not None and not _text(fact['contextId']):
        return 'invalid-context-id'
    if fact.get('sourceUrl') is not None:
        from urllib.parse import urlsplit
        try:
            url = urlsplit(fact['sourceUrl'])
            if url.scheme != 'https' or not url.hostname or url.username or url.password:
                return 'invalid-source-url'
        except (ValueError, TypeError, AttributeError):
            return 'invalid-source-url'
    return None


def _validate(payload):
    if not isinstance(payload, dict) or set(payload) != {'schemaVersion', 'ruleset', 'mode', 'dataset', 'facts', 'rows'}:
        return 'invalid-top-level-fields'
    if payload['schemaVersion'] != SCHEMA_VERSION or payload['ruleset'] != RULESET:
        return 'unsupported-schema-or-ruleset'
    if payload['mode'] not in ('disclosure-reconstruction', 'observed-pipeline'):
        return 'invalid-mode'
    ds = payload['dataset']
    if not isinstance(ds, dict) or set(ds) != {'id', 'version'} or not all(_id(v) for v in ds.values()):
        return 'invalid-dataset-identity'
    facts, rows = payload['facts'], payload['rows']
    if not isinstance(facts, list) or not 1 <= len(facts) <= 2000 or not isinstance(rows, list) or not 1 <= len(rows) <= 2000:
        return 'invalid-or-empty-batch'
    ids = set()
    for f in facts:
        error = _fact_error(f)
        if error:
            return error
        if f['factId'] in ids:
            return 'duplicate-fact-id'
        ids.add(f['factId'])
    row_ids = set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'rowId', 'factId', 'cutoff', 'expected'}:
            return 'invalid-row-fields'
        if not _id(row['rowId']) or not _id(row['factId']) or row['factId'] not in ids or row['rowId'] in row_ids:
            return 'invalid-or-duplicate-row-identity'
        if _instant(row['cutoff']) is None or not _identity(row['expected']) or set(row['expected']) != IDENTITY:
            return 'invalid-row-cutoff-or-expected-context'
        row_ids.add(row['rowId'])
    return None


def _context(fact, expected):
    missing = False
    for k in IDENTITY:
        if fact.get(k) is None:
            missing = True
        elif (_dimensions(fact[k]) if k == 'dimensions' else fact[k]) != (_dimensions(expected[k]) if k == 'dimensions' else expected[k]):
            return 'FAIL', 'context-mismatch'
    return ('UNKNOWN', 'missing-context-evidence') if missing else ('PASS', 'exact-declared-context')


def _version(fact, expected, cutoff, mode, facts):
    if not _identity(fact) or _key(fact) != _key(expected):
        return 'UNKNOWN', 'selected-context-not-established', [fact['factId']]
    matched = []
    incomplete = False
    for other in facts:
        verdict, _ = _context(other, expected)
        if verdict == 'FAIL':
            continue
        if verdict == 'UNKNOWN':
            incomplete = True
            continue
        accepted = _instant(other.get('acceptedAt'))
        if accepted is None:
            incomplete = True
            continue
        if accepted > cutoff:
            continue
        if mode == 'observed-pipeline':
            observed = _instant(other.get('observedAt'))
            if observed is None or observed < accepted:
                incomplete = True
                continue
            if observed > cutoff:
                continue
        matched.append(other)
    refs = [fact['factId']]
    if not matched:
        return 'UNKNOWN', 'no-established-eligible-candidate', refs
    latest = max(_instant(f['acceptedAt']) for f in matched)
    selected = sorted((f for f in matched if _instant(f['acceptedAt']) == latest), key=lambda f: f['factId'])
    refs = sorted({fact['factId'], selected[0]['factId']})
    if len({f['value'] for f in selected}) > 1:
        conflict = next(f for f in selected if f['value'] != selected[0]['value'])
        refs = sorted(set(refs) | {conflict['factId']})
        return 'FAIL', 'conflicting-latest-values', refs
    if any(not f.get('accession') or not f.get('documentSha256') for f in selected):
        return 'UNKNOWN', 'missing-version-provenance', refs
    if len({(f['accession'], f['documentSha256']) for f in selected}) > 1:
        conflict = next(f for f in selected if (f['accession'], f['documentSha256']) != (selected[0]['accession'], selected[0]['documentSha256']))
        refs = sorted(set(refs) | {conflict['factId']})
        return 'FAIL', 'ambiguous-latest-provenance', refs
    if incomplete:
        return 'UNKNOWN', 'incomplete-candidate-evidence', refs
    if not fact.get('accession') or not fact.get('documentSha256'):
        return 'UNKNOWN', 'missing-selected-version-provenance', refs
    signature = lambda f: (f.get('acceptedAt') and _instant(f['acceptedAt']), f.get('accession'), f.get('documentSha256'), f['value'])
    if signature(fact) != signature(selected[0]):
        return 'FAIL', 'selected-is-not-latest-eligible-declared-version', refs
    # Selection also requires this particular record to have been observed.
    if mode == 'observed-pipeline' and (_instant(fact.get('observedAt')) is None or _instant(fact['observedAt']) > cutoff or _instant(fact['observedAt']) < latest):
        return 'UNKNOWN', 'selected-observation-not-established', refs
    return 'PASS', 'latest-eligible-within-supplied-candidates', refs


def audit_batch(payload):
    """Return a deterministic report. PASS is conditional, not authentication.

    No network, file access, repairs or telemetry. Invalid batches fail closed.
    inputSha256 covers canonical JSON; CLI separately records raw-file hashes.
    """
    from . import __version__
    report = dict(schemaVersion=SCHEMA_VERSION, tool='ahasignals-pit', version=__version__,
                  ruleset=RULESET, status='invalid', gate='ERROR', inputSha256=None,
                  dataset=None, mode=None, checks=[], errors=[], excludedChecks=[],
                  summary=dict(rows=0, applicableChecks=0, passed=0, failed=0, unknown=0),
                  limitations=LIMITATIONS[:])
    try:
        raw = json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()
        if len(raw) > 8_000_000:
            raise ValueError('batch-too-large')
        report['inputSha256'] = hashlib.sha256(raw).hexdigest()
        error = _validate(payload)
    except (ValueError, TypeError, RecursionError, OverflowError):
        error = 'invalid-json-compatible-batch'
    if error:
        report['errors'] = [dict(code=error)]
        return report
    report.update(status='complete', dataset=deepcopy(payload['dataset']), mode=payload['mode'])
    facts = {f['factId']: f for f in payload['facts']}
    counts = {'PASS': 0, 'FAIL': 0, 'UNKNOWN': 0}
    for row in payload['rows']:
        fact, cutoff = facts[row['factId']], _instant(row['cutoff'])
        refs = [fact['factId']]

        def add(rule, verdict, reason, evidence=refs):
            counts[verdict] += 1
            report['checks'].append(dict(rowId=row['rowId'], factId=fact['factId'],
                cutoff=row['cutoff'], ruleId=rule, ruleVersion='1.0.0', verdict=verdict,
                reason=reason, evidenceRefs=evidence[:], evidenceBasis='caller-supplied-fields',
                assumption='Declared fields are accurate; candidate history is supplied by the caller.',
                remediation=RULES[rule][1]))

        accepted, observed = _instant(fact.get('acceptedAt')), _instant(fact.get('observedAt'))
        add('PIT-TIME-001', 'UNKNOWN' if accepted is None else 'PASS' if accepted <= cutoff else 'FAIL',
            'missing-acceptance-time' if accepted is None else 'acceptance-by-cutoff' if accepted <= cutoff else 'acceptance-after-cutoff')
        if payload['mode'] == 'observed-pipeline':
            if observed is None:
                add('PIT-TIME-002', 'UNKNOWN', 'missing-observation-time')
            elif observed > cutoff:
                add('PIT-TIME-002', 'FAIL', 'observation-after-cutoff')
            elif accepted is None:
                add('PIT-TIME-002', 'UNKNOWN', 'missing-acceptance-for-clock-order')
            elif observed < accepted:
                add('PIT-TIME-002', 'FAIL', 'observation-before-acceptance')
            else:
                add('PIT-TIME-002', 'PASS', 'declared-observation-by-cutoff')
        else:
            report['excludedChecks'].append(dict(rowId=row['rowId'], ruleId='PIT-TIME-002', reason='mode-does-not-assert-observed-availability'))
        add('PIT-CONTEXT-001', *_context(fact, row['expected']))
        verdict, reason, evidence = _version(fact, row['expected'], cutoff, payload['mode'], payload['facts'])
        add('PIT-VERSION-001', verdict, reason, evidence)
        complete = all(fact.get(k) for k in ('accession', 'contextId', 'documentSha256', 'sourceUrl'))
        add('PIT-EVIDENCE-001', 'PASS' if complete else 'UNKNOWN',
            'declared-provenance-present-not-authenticated' if complete else 'missing-provenance-fields')
    report['summary'] = dict(rows=len(payload['rows']), applicableChecks=sum(counts.values()),
                             passed=counts['PASS'], failed=counts['FAIL'], unknown=counts['UNKNOWN'])
    report['gate'] = 'FAIL' if counts['FAIL'] else 'UNKNOWN' if counts['UNKNOWN'] else 'PASS'
    return report
