"""Review day-trader-skill JSON against immutable reviewed filing annotations.

No upstream code execution, credentials, fetching, model calls or trading. Original
HTML, when supplied, is hash-bound and its iXBRL numbers are re-extracted. Without
it the evidence level remains explicitly annotation-only. Coverage is finite.
"""
from datetime import datetime
from decimal import Decimal, InvalidOperation
from hashlib import sha256
from importlib.resources import files
import json
import re
import xml.etree.ElementTree as ET
from .claim_review import NS

UPSTREAM = '3d0f4ef6986f4984b7c6bd46f7ff4f87744c3abd'
METRICS = ('revenue', 'gross_profit', 'operating_income', 'net_income', 'eps_diluted',
           'gross_margin', 'operating_margin', 'net_margin', 'revenue_yoy', 'net_income_yoy', 'eps_yoy')
RATIOS = {'operating_margin': 'operating_income', 'net_margin': 'net_income'}


def manifest():
    return json.loads(files('ahasignals_pit').joinpath('workflow_data/earnings-source.json').read_text())


def number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ValueError('Invalid financial value')
    try:
        n = Decimal(str(value))
    except InvalidOperation:
        raise ValueError('Invalid financial value') from None
    if not n.is_finite() or len(str(value)) > 100:
        raise ValueError('Invalid financial value')
    return n


def clock(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})', value):
        raise ValueError('Explicit timezone and seconds required')
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def bind(document, m):
    if not isinstance(document, bytes) or len(document) > 4_000_000 or sha256(document).hexdigest() != m['documentSha256']:
        raise ValueError('Source differs from reviewed bytes')
    if re.search(br'<!\s*(DOCTYPE|ENTITY)', document, re.I):
        raise ValueError('Unsupported XML')
    root = ET.fromstring(document)
    for f in m['facts']:
        contexts = [c for c in root.findall('.//x:context', NS) if c.get('id') == f['contextId']]
        if len(contexts) != 1:
            raise ValueError('Ambiguous context')
        c = contexts[0]
        identifier = c.find('x:entity/x:identifier', NS)
        if (identifier is None or identifier.text != m['cik'] or identifier.get('scheme') != 'http://www.sec.gov/CIK'
                or c.findtext('x:period/x:startDate', namespaces=NS) != f['start']
                or c.findtext('x:period/x:endDate', namespaces=NS) != f['end']
                or c.find('.//x:segment', NS) is not None or c.find('.//x:scenario', NS) is not None):
            raise ValueError('Context differs')
        nodes = [n for n in root.findall('.//ix:nonFraction', NS) if n.get('name') == f['concept'] and n.get('contextRef') == f['contextId']]
        if not nodes or not any(n.get('id') == f['factId'] for n in nodes):
            raise ValueError('Fact missing')
        for n in nodes:
            units = [u for u in root.findall('.//x:unit', NS) if u.get('id') == n.get('unitRef')]
            if (len(units) != 1 or len(units[0]) != 1 or units[0].findtext('x:measure', namespaces=NS) != 'iso4217:USD'
                    or n.get('format') != 'ixt:num-dot-decimal' or n.get('scale') != '3'
                    or n.get('sign', '') not in ('', '-') or len(n)
                    or not re.fullmatch(r'\d{1,3}(?:,\d{3})*|\d+', n.text or '')):
                raise ValueError('Unsupported unit or transform')
            actual = Decimal(n.text.replace(',', '')) * 1000 * (-1 if n.get('sign') == '-' else 1)
            if actual != Decimal(f['value']):
                raise ValueError('Source number differs')


def review_earnings_export(payload, cutoff, document=None, mode='disclosure-reconstruction', analysis=''):
    """Native facts.py --json array in; individual checks and replacement facts out.

    This does not interpret free-form prose or claim general company coverage.
    Unsupported fields, periods, issuers and derivatives remain UNKNOWN.
    """
    at = clock(cutoff)
    if mode not in ('disclosure-reconstruction', 'observed-pipeline'):
        raise ValueError('Unknown time basis')
    if not isinstance(analysis, str) or len(analysis) > 12000:
        raise ValueError('Analysis too large')
    encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode()
    if len(encoded) > 4_000_000 or not isinstance(payload, list) or not 1 <= len(payload) <= 50:
        raise ValueError('Supply the facts.py --json array, not metrics.json')
    m = manifest()
    level = 'REVIEWED_ANNOTATIONS_ONLY'
    blocked = None
    if document is not None:
        try:
            bind(document, m)
            level = 'REVIEWED_ORIGINAL_REEXTRACTED'
        except (ValueError, ET.ParseError):
            level, blocked = 'SOURCE_BINDING_FAILED', 'SOURCE_BINDING_FAILED'
    if at < clock(m['acceptedAt']):
        blocked = 'FILING_AFTER_CUTOFF'
    elif mode == 'observed-pipeline' and at < clock(m['sourceObservedAt']):
        blocked = 'NO_CAPTURE_BY_CUTOFF'
    checks, revised, notes = [], [], []
    for company in payload:
        if not isinstance(company, dict) or not isinstance(company.get('result'), dict):
            raise ValueError('Invalid upstream result')
        result = company['result']
        cik = str(result.get('cik', ''))
        if not re.fullmatch(r'\d{1,10}', cik):
            raise ValueError('Missing CIK')
        cik = cik.zfill(10)
        rows = result.get('rows')
        if not isinstance(rows, list) or len(rows) > 100:
            raise ValueError('Invalid rows')
        if not rows:
            checks.append(dict(cik=cik, status='UNKNOWN', reason='NO_QUARTER_ROWS'))
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                raise ValueError('Invalid row')
            row_checks = []
            for metric in METRICS:
                if row.get(metric) is None:
                    continue
                supplied = number(row[metric])
                out = dict(cik=cik, row=i, metric=metric, suppliedValue=str(supplied),
                           start=row.get('start'), end=row.get('end'), status='UNKNOWN')
                bound = [f for f in m['facts'] if f['metric'] == metric]
                needed = [f for f in m['facts'] if f['metric'] in ('revenue', RATIOS[metric])] if metric in RATIOS else bound
                reason = blocked
                if not reason and cik != m['cik']:
                    reason = 'ISSUER_NOT_REVIEWED'
                if not reason and not needed:
                    reason = 'METRIC_NOT_REVIEWED'
                if not reason and any((row.get('start'), row.get('end')) != (f['start'], f['end']) for f in needed):
                    reason = 'PERIOD_NOT_REVIEWED'
                if not reason and row.get('derived') is not False:
                    reason = 'DERIVATION_OR_BASIS_NOT_DECLARED'
                if reason:
                    out['reason'] = reason
                else:
                    if metric in RATIOS:
                        values = {f['metric']: Decimal(f['value']) for f in needed}
                        expected = (100 * values[RATIOS[metric]] / values['revenue']).quantize(Decimal('0.1'))
                        unit = 'percent'
                    else:
                        expected, unit = Decimal(bound[0]['value']), bound[0]['unit']
                    out.update(status='SUPPORTED' if supplied == expected else 'CORRECTION_REQUIRED',
                               reason='VALUE_MATCHES_REVIEWED_CONTEXT' if supplied == expected else 'VALUE_DIFFERS_FROM_REVIEWED_CONTEXT',
                               expectedValue=str(expected), unit=unit, sourceFacts=needed,
                               source={k:m[k] for k in ('sourceUrl','accession','cik','documentSha256','acceptedAt','acceptedAtBasis','sourceObservedAt','reviewedAt','location')})
                    revised.append(f"CIK {cik}, {row['start']} to {row['end']}: {metric} = {expected} {unit} (consolidated; {m['accession']}).")
                row_checks.append(out)
            if not row_checks:
                row_checks.append(dict(cik=cik, row=i, status='UNKNOWN', reason='NO_SUPPORTED_NUMERIC_FIELDS'))
            checks.extend(row_checks)
            # Never let a row-level date stand in for individual source dates.
            if row.get('filed'):
                notes.append(dict(cik=cik, row=i, suppliedRowFiled=row['filed'], status='NOT_USED_AS_PER_FACT_PROVENANCE'))
        for metric, value in (result.get('ttm') or {}).items():
            checks.append(dict(cik=cik, metric='ttm.'+metric, suppliedValue=str(number(value)), status='UNKNOWN', reason='TTM_INPUTS_NOT_BOUND'))
        extras = set(result) - {'entity','cik','rows','ttm','concepts'}
        if extras:
            checks.append(dict(cik=cik, status='UNKNOWN', reason='UNREVIEWED_RESULT_FIELDS', fields=sorted(extras)))
        for i, row in enumerate(rows):
            extras = set(row) - set(METRICS) - {'end','start','fiscal','derived','filed','form'}
            if extras:
                checks.append(dict(cik=cik, row=i, status='UNKNOWN', reason='UNREVIEWED_ROW_FIELDS', fields=sorted(extras)))
    statuses = [c['status'] for c in checks]
    status = 'CORRECTION_REQUIRED' if 'CORRECTION_REQUIRED' in statuses else ('UNKNOWN' if not statuses or 'UNKNOWN' in statuses else 'SUPPORTED')
    unknown = sum(s == 'UNKNOWN' for s in statuses)
    return dict(schemaVersion='1.0', status=status, evidenceLevel=level, cutoff=cutoff, mode=mode,
                inputSha256=sha256(encoded).hexdigest(), originalAnalysis=analysis,
                analysisStatus='NOT_SEMANTICALLY_REVIEWED', checks=checks, rowDateNotes=notes,
                revisedAnalysis='\n'.join(dict.fromkeys(revised)) or 'No source-supported replacement can be supplied.',
                unresolved=f'{unknown} numeric checks remain UNKNOWN. Cash generation, growth explanations and investment conclusions are not established by these checks.',
                boundary='Selected reviewed contexts only. SUPPORTED refers to numeric fields, not the entire analysis. Offline annotations are not a fresh original-source check. No model evaluation or independent assurance.',
                adapter=dict(name='day-trader-skill facts.py --json', testedCommit=UPSTREAM))


def markdown(result):
    lines = ['# Earnings review', '', result['status'], '', 'Evidence: '+result['evidenceLevel'], '',
             '## Source-supported replacement', '', result['revisedAnalysis'], '', '## Individual checks', '']
    for c in result['checks']:
        lines.append('- '+c.get('metric', 'row')+': '+c['status']+' — '+c['reason'])
        if 'source' in c:
            lines.append('  Source: '+c['source']['sourceUrl']+'; '+c['source']['location'])
    lines += ['', '## Still unresolved', '', result['unresolved'], '', '## Original analysis (unreviewed text)', '', result['originalAnalysis'], '', result['boundary'], '']
    return '\n'.join(lines)
