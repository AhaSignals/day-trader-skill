"""Offline financial research handoff. Provider rows are not filing evidence."""
import hashlib
from importlib.resources import files
import json
import re
from . import __version__, select_fact, audit_batch

ENDPOINTS = ('us_income', 'us_balancesheet', 'us_cashflow', 'us_fina_indicator')


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def no_credentials(value):
    """Reject secret-shaped keys at any depth, without echoing their values."""
    if isinstance(value, dict):
        for key, item in value.items():
            if re.search(r'(?i)(token|password|secret|api.?key|authorization)', str(key)):
                raise ValueError('Remove credential fields before analysis.')
            no_credentials(item)
    elif isinstance(value, list):
        for item in value:
            no_credentials(item)


def demo_input():
    return json.loads(files('ahasignals_pit').joinpath('workflow_data/period-case.json').read_text())


def demo():
    case = demo_input()
    quarter = select_fact(case['facts'], case['query'])
    half_query = dict(case['query'], start='2025-01-01')
    half = select_fact(case['facts'], half_query)
    observed = select_fact(case['facts'], dict(case['query'], mode='observed-pipeline'))
    assert quarter['status'] == half['status'] == 'answer'
    return {'case': case['id'], 'quarter': quarter, 'halfYear': half,
            'observedPipeline': observed, 'sourceReview': case['sourceReview'],
            'conclusion': 'Quarterly operating income is positive; half-year operating income is negative. Neither establishes net profit or cash generation.',
            'boundary': case['boundary']}


def inspect_vendor(payload):
    """Inventory a captured Tushare response or a user-exported row array.

    No concept aliases, units, starts, accession numbers or clocks are inferred.
    A receipt timestamp describes acquisition, never filing availability.
    """
    no_credentials(payload)
    if not isinstance(payload, dict) or payload.get('endpoint') not in ENDPOINTS:
        raise ValueError('Choose a supported financial endpoint.')
    data = payload.get('data')
    if isinstance(data, dict):
        fields, items = data.get('fields'), data.get('items')
        if (not isinstance(fields, list) or not fields or len(fields) != len(set(fields))
                or not all(isinstance(f, str) for f in fields) or not isinstance(items, list)
                or any(not isinstance(row, list) or len(row) != len(fields) for row in items)):
            raise ValueError('Invalid fields/items table.')
        rows = [dict(zip(fields, row)) for row in items]
    elif isinstance(data, list) and all(isinstance(row, dict) for row in data):
        rows = data
    else:
        raise ValueError('Use data as fields/items or a list of row objects.')
    if len(rows) > 10000:
        raise ValueError('Use at most 10000 rows per local inspection.')
    no_credentials(rows)
    checks = []
    required = ('ts_code', 'end_date')
    for index, row in enumerate(rows):
        missing = [k for k in required if row.get(k) in (None, '')]
        checks.append({'rowIndex': index, 'rowSha256': digest(row),
                       'status': 'NEEDS_CONTEXT', 'missingIdentityFields': missing,
                       'presentFields': sorted(row)})
    return {'status': 'EMPTY' if not rows else 'NEEDS_CONTEXT', 'rowCount': len(rows),
            'endpoint': payload['endpoint'], 'provider': 'tushare-compatible-input',
            'receiptSha256': digest(payload), 'rows': checks,
            'requiredReview': ['Match issuer identity, actual period start/end and single-quarter versus cumulative duration.',
                               'Confirm metric definition, currency/scale, consolidated or segment scope, and GAAP/non-GAAP basis.',
                               'Obtain a specific filing and literal context before creating audit facts; preserve vendor rows separately.',
                               'Record actual acquisition time and intended cutoff; never turn period end or notice_date into an exact acceptance timestamp.'],
            'nextStep': 'Use the independent filing case for practice, or prepare an audit batch from reviewed source facts and run check_financial_facts.',
            'boundary': 'Shape inventory only. Values and provenance have not been verified. No automatic vendor-to-filing match. A returned page is not evidence of complete vendor history.'}


def dispatch(operation, payload=None):
    if operation == 'demo':
        if payload not in (None, {}):
            raise ValueError('Demo accepts no data.')
        return demo()
    if operation == 'inspect_vendor':
        return inspect_vendor(payload)
    if operation == 'check_financial_facts':
        no_credentials(payload)
        return audit_batch(payload)
    raise ValueError('Unknown operation.')


def packet(operation, payload=None):
    no_credentials(payload)
    result = dispatch(operation, payload)
    body = {'schemaVersion': '1.0', 'packageVersion': __version__, 'operation': operation,
            'input': payload, 'result': result}
    return {**body, 'sha256': digest(body),
            'integrityMeaning': 'Detects changed bytes; not a signature or independent source authentication.'}


def replay(saved):
    if not isinstance(saved, dict) or saved.get('packageVersion') != __version__:
        raise ValueError('Replay with the exact original package version.')
    body = {k: saved[k] for k in ('schemaVersion', 'packageVersion', 'operation', 'input', 'result')}
    if body['schemaVersion'] != '1.0' or digest(body) != saved.get('sha256'):
        raise ValueError('Packet checksum mismatch.')
    if dispatch(body['operation'], body['input']) != body['result']:
        raise ValueError('Recomputed result differs.')
    return {'status': 'reproduced', 'sha256': saved['sha256'], 'packageVersion': __version__}


def markdown(saved):
    replay(saved)
    result = saved['result']
    if saved['operation'] == 'demo':
        q, h = result['quarter']['value'], result['halfYear']['value']
        return ('# 财报期间检查\n\n'
                f'2025 年 4—6 月营业利润：{q:,.0f} USD。\n\n'
                f'2025 年 1—6 月营业损益：{h:,.0f} USD。\n\n'
                '两者期间不同，并不矛盾。不能据此判断净利润、现金流或投资价值。\n\n'
                '本例是已审阅申报事实，不是 Tushare 实际返回数据。历史采集时间未知，不能证明系统当时已取得数据。\n\n'
                f"来源与审阅：[期间案例]({result['sourceReview']})。AI-assisted single-operator research.\n\n"
                f"证据包 SHA-256：`{saved['sha256']}`。校验值不构成独立认证。\n")
    if saved['operation'] == 'inspect_vendor':
        return ('# 财务数据接入检查\n\n'
                f"收到 {result['rowCount']} 行；状态 `{result['status']}`。\n\n"
                '字段接入完成，财务口径尚未验证。请核对期间起止、单季或累计、币种单位、合并或分部范围及具体来源。不得将此报告作为财务事实已通过审阅的证明。\n\n'
                f"证据包 SHA-256：`{saved['sha256']}`。原始输入保留在本地 JSON 中，分享前检查权限。\n")
    return ('# Financial fact check\n\n'
            f"Gate: **{result['gate']}**. Applies only to supplied fields and checked rules.\n\n"
            f"Packet SHA-256: `{saved['sha256']}`. Inspect per-row findings in the JSON packet.\n")
