"""Explicit one-request capture. Imported only by the opt-in collector, never MCP."""
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import urllib.request
from .workflow import ENDPOINTS, inspect_vendor


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('Redirect refused.')


def fetch(endpoint, symbol, period, token):
    if endpoint not in ENDPOINTS or not re.fullmatch(r'[A-Z0-9.\-]{1,24}', symbol):
        raise ValueError('Invalid endpoint or symbol.')
    if not re.fullmatch(r'\d{8}', period):
        raise ValueError('Use YYYYMMDD.')
    datetime.strptime(period, '%Y%m%d')
    if not isinstance(token, str) or not token.strip() or len(token) > 512:
        raise ValueError('A personal token is required.')
    params = {'ts_code': symbol, 'period': period}
    request = urllib.request.Request('https://api.tushare.pro', data=json.dumps(
        {'api_name': endpoint, 'token': token, 'params': params, 'fields': ''}).encode(),
        headers={'Content-Type': 'application/json', 'User-Agent': 'AhaSignals-user-capture/0.3.0'}, method='POST')
    # One bounded TLS request. Never fall back to HTTP or send credentials on redirect.
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=25) as response:
        raw = response.read(8_000_001)
    if len(raw) > 8_000_000:
        raise ValueError('Response too large.')
    # Do not publish provider messages: they can contain secrets or request details.
    if token.encode() in raw:
        raise ValueError('Credential echoed by provider; response discarded.')
    result = json.loads(raw)
    if result.get('code') != 0:
        raise ValueError('Provider denied or failed the request. Check personal entitlement locally; no retry or purchase was attempted.')
    captured = {'provider': 'tushare', 'endpoint': endpoint, 'params': params,
                'fetchedAt': datetime.now(timezone.utc).isoformat(),
                'responseSha256': hashlib.sha256(raw).hexdigest(), 'data': result.get('data'),
                'coverage': 'One response only; pagination and full history completeness are not established.'}
    inspect_vendor(captured)
    return captured


def write_private(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
    # O_EXCL refuses existing files, including symlinks; credentials are never written.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
